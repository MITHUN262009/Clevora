# Clevora production-data upgrade

## Goal
Replace demonstration content with each student's real saved information, while keeping the current mobile design and smooth scrolling.

## Changes
- Hide visible vertical and horizontal scrollbars while preserving touch, mouse-wheel, and swipe scrolling.
- Make new email sign-ups enter the app immediately without email confirmation.
- Remove the default girl photo and all invented student, timetable, academic, and campus content. Show clear empty states until the student adds real information.
- Add an editable profile photo, a broad stream selector, and a course selector filtered by the chosen stream. Save these choices to the student's private profile.
- Refresh academic suggestions and labels from the selected stream and course; never inject fake personal records.
- Add an Attendance plus button so students can choose a subject and begin tracking its attended/missed sessions.
- Add an Exam Planner section with its own plus action, exam schedule creation, progress tracking, and completion controls using saved reminders.
- Preserve existing notes, tasks, expenses, reminders, dark mode, search, navigation, and account security.

## Technical details
- Extend private profiles with `stream` and `avatar_url` fields and add a private profile-photo storage bucket.
- Reuse the existing attendance and reminders records for attendance trackers and exam plans; no duplicate data model.
- Validate saves, upload only image files, isolate every student's records, and update generated data types.
- Verify on the current mobile viewport: hidden scrollbars, profile dependencies, photo upload UI, attendance creation, exam creation/tracking, and immediate sign-up behavior.
